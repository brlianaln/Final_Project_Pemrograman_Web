<div <?php echo e($attributes->class(['fi-dropdown-list p-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\laragon\data\FP_FIX\Final_Project_Pemrograman_Web\backend\backend_fp\vendor\filament\support\src\/../resources/views/components/dropdown/list/index.blade.php ENDPATH**/ ?>